package com.cg.emp.exception;

public class EmployeeException extends Exception{

	public EmployeeException(String arg0) {
		super(arg0);
	}
	
	

}
